﻿using System;
using System.Text;

namespace PW_4
{
    class Program
    {
        static void Main()
        {
            Console.Title = "Лабораторна 20 // Варіант 2 // Піскун Іван // \"Призма-трикутник\"";
            Console.OutputEncoding = Encoding.UTF8;

            

            Console.ReadKey();
        }
    }
}
